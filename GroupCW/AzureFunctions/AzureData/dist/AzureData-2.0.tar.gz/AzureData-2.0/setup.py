# setup.py
from distutils.core import setup

setup(
    name='AzureData',
    version='2.0',
    py_modules=['AzureData'],
)